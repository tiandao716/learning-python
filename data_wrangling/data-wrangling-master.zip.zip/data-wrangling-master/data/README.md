## Descriptions of Files in this folder

This folder could be deleted in the future, but leaving it for now, because it feels like it should be here.

| File Name | Description                            |
|-----------|----------------------------------------|
| who       | copies files used in Ch. 3 in raw form |
|           |                                        |
